var myaddress = "0x506597210a570201CB5fa1D8B31c88766488D187"
var myprivatekey = "14b97514c4b2c9c1897b43d0bc6830d467dbd3ca625469a1ea7f98c1c828a872" 
var myseed = "asd" //if your privatekey is stored in a wallet with no privatekey accessibility example a (hardwarewallet) make sure you still input your pubilc ETH address
var networks = "1" //1 = ETH , 56 = BNB , 137 = POLYGON
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.